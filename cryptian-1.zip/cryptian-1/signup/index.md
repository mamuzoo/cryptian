***
date="2018"
title="get in touch"
***
<form method="post" name="contact" netlify>
<label form-"1NAME">first name</LABEL>
<BR>
<INPUT type="text" id="fname" name="firstname" placeholder="your first name..">
<br>
<br>
<label form="lastname">last name</label>
<br>
<input type="text id="text" id="lastname" name="lastname" placeholder="your last name..">
<br>
<br>
<label form="email>email</label>
<br>
<input type="text" id="email" name=="email" place holder="email@example.com">
<br>
<br>
<label for="signup">signup</label>
<br>
<br>
<input type="submit" value="submit" style="">
</form>