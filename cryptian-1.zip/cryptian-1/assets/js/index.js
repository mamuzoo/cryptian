<div data-netlify-identity-menu></div> 
const netlifyIdentity = require("netlify-identity-widget");
componentDidMount(d){    
  netlifyIdentity.init();
}